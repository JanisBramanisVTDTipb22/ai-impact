<h1>How ai could impact climate change<h1>
<h1>Live counter<h1>